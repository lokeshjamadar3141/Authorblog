INTRODUCTION:
Login Redirect per Role provides an Configuration page to set default URL to be 
redirected after login as per Role.

If more than one Role is assigned to User, URL of Role with lesser weight will 
be used or it will be redirected to default URL.

Admin can set Default Redirection URL as well as URL as per Roles.

REQUIREMENTS:
None

INSTALLATION:
Enable Login Redirect Per Role from Extends url.

CONFIGURATION:
Path : Configuration -> Login Redirect per Role 
( ie. admin/people/login-redirect-per-role )

ROADMAP:
Adding Logout URL as per ROLE.
